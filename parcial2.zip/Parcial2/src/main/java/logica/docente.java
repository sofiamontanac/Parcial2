package logica;

import javax.persistence.Entity;

@Entity
 public class docente extends persona {
   //private int id_docente;
    public docente() {
    }

    public docente(String cedula, String nombre, String apellido, String celular) {
        super(cedula, nombre, apellido, celular);
    }

}
