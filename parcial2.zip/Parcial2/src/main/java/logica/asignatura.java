package logica;

import java.util.List;

public class asignatura {
    
    private int id_asignatura;
    private String nombre_asig;  
    private String Descripcion;
    private String salon;
    private String horario;
    private List<docente> ListaDocente;
    

    public asignatura() {
    }

    public asignatura(int id_asignatura, String nombre_asig, String Descripcion, String salon, String horario, List<docente> ListaDocente) {
        this.id_asignatura = id_asignatura;
        this.nombre_asig = nombre_asig;
        this.Descripcion = Descripcion;
        this.salon = salon;
        this.horario = horario;
        this.ListaDocente = ListaDocente;
    }

    public int getId_asignatura() {
        return id_asignatura;
    }

    public void setId_asignatura(int id_asignatura) {
        this.id_asignatura = id_asignatura;
    }

    public String getNombre_asig() {
        return nombre_asig;
    }

    public void setNombre_asig(String nombre_asig) {
        this.nombre_asig = nombre_asig;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public String getSalon() {
        return salon;
    }

    public void setSalon(String salon) {
        this.salon = salon;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public List<docente> getListaDocente() {
        return ListaDocente;
    }

    public void setListaDocente(List<docente> ListaDocente) {
        this.ListaDocente = ListaDocente;
    }

}
