package logica;

import javax.persistence.Entity;
import javax.persistence.OneToOne;

@Entity

public class rector extends persona {
     //private int id_rector;
    @OneToOne
    private usuario unsuario;

    public rector(usuario unsuario, String cedula, String nombre, String apellido, String celular) {
        super(cedula, nombre, apellido, celular);
        this.unsuario = unsuario;
    }

    public usuario getUnsuario() {
        return unsuario;
    }

    public void setUnsuario(usuario unsuario) {
        this.unsuario = unsuario;
    }
    
}
