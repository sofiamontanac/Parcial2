package logica;

public class usuario {
    
    private int id_usuario;
    private String nombreusuario;
    private String contrasena;
    private String rol;

    public usuario() {
    }

    public usuario(int id_usuario, String nombreusuario, String contrasena, String rol) {
        this.id_usuario = id_usuario;
        this.nombreusuario = nombreusuario;
        this.contrasena = contrasena;
        this.rol = rol;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getNombreusuario() {
        return nombreusuario;
    }

    public void setNombreusuario(String nombreusuario) {
        this.nombreusuario = nombreusuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }
    
}
